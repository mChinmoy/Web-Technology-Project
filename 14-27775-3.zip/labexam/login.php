<?php

	$servername ="localhost";
	$username 	="root";
	$password 	="";
	$dbname 	="web-tech";
	
	$conn = mysqli_connect($servername, $username, $password, $dbname);
	
	if(!$conn){
		die("Connection Error!".mysqli_connect_error());
	}
	
	$sql = "select * from user";
	$result = mysqli_query($conn, $sql);
	
	if(mysqli_num_rows($result)>0){
		
		while($row=mysqli_fetch_assoc($result)){
			//echo "<br/>NAME: ".$row['name']."<br/>PASSWORD: ".$row['password']."<br/><br/>";
		}
		
	}else{
		echo "Result not found!";
	}

	mysqli_close($conn);
?>



<fieldset>
    <legend><b>LOGIN</b></legend>
    <form>
        <table>
            <tr>
                <td>User Name</td>
				<td>:</td>
                <td><input type="text"></td>
            </tr>
            <tr>
                <td>Password</td>
				<td>:</td>
                <td><input type="password"></td>
            </tr>
        </table>
        <hr />
		<input name="remember" type="checkbox">Remember Me
		<br/><br/>
        <input type="submit" value="Submit">        
		<a href="forgot_password.html">Forgot Password?</a>
    </form>
</fieldset>